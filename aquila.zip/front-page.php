<?php
/**
 * Front Page Template
 * 
 * @package Aquila
 */
 get_header();
 ?>

<div>
    Front Page
</div>

<?php
 get_footer();
?>