<?php
/**
 * theme footer template
 * 
 * @package Aquila
 */
wp_footer(  );
?>
<footer>Footer</footer>
<?php wp_footer(  ); ?>
    </div>
</div>
</body>
</html>