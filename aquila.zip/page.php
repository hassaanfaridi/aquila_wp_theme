<?php
/**
 * Page Template
 * 
 * @package Aquila
 */
 get_header();
 ?>

<div>
    Single Page 
</div>

<?php
 get_footer();
?>